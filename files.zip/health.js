'use strict';

const express = require('express');
const sessionStore = require('../agent/memory');
const config = require('../../config');

const router = express.Router();
const startTime = Date.now();

/**
 * GET /health
 *
 * Endpoint de health check para monitoramento e load balancers.
 *
 * Response:
 *   { status, uptime, environment, sessions, model }
 */
router.get('/', (req, res) => {
  res.json({
    status:      'ok',
    uptime:      `${Math.floor((Date.now() - startTime) / 1000)}s`,
    environment: config.server.nodeEnv,
    sessions:    sessionStore.size,
    model:       config.openai.model,
  });
});

module.exports = router;
