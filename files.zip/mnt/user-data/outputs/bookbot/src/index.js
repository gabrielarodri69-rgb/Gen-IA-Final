'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const config = require('../config');
const logger = require('./utils/logger');
const chatRouter = require('./routes/chat');
const healthRouter = require('./routes/health');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// ── Segurança ────────────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: config.server.nodeEnv === 'production' ? false : '*' }));

// ── Rate Limiting ────────────────────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max:      config.rateLimit.maxRequests,
  message:  { error: 'Muitas requisições. Aguarde um momento e tente novamente.' },
  standardHeaders: true,
  legacyHeaders:   false,
});
app.use('/api/', limiter);

// ── Parsers ──────────────────────────────────────────────────────────────────
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: false }));

// ── Rotas ────────────────────────────────────────────────────────────────────
app.use('/health', healthRouter);
app.use('/api/chat', chatRouter);

// Rota padrão
app.get('/', (req, res) => {
  res.json({
    name:    'BookBot API',
    version: '1.0.0',
    docs:    'Consulte o README.md para documentação completa.',
  });
});

// 404
app.use((req, res) => {
  res.status(404).json({ error: `Rota ${req.method} ${req.path} não encontrada.` });
});

// ── Tratamento global de erros ────────────────────────────────────────────────
app.use(errorHandler);

// ── Inicialização ─────────────────────────────────────────────────────────────
const { port, nodeEnv } = config.server;
app.listen(port, () => {
  logger.info(`📚 BookBot API rodando na porta ${port} [${nodeEnv}]`);
  logger.info(`   Health: http://localhost:${port}/health`);
  logger.info(`   Chat:   http://localhost:${port}/api/chat`);
});

module.exports = app; // exportado para uso nos testes
