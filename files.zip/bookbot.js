'use strict';

const OpenAI = require('openai');
const config = require('../../config');
const sessionStore = require('./memory');
const { buildSystemPrompt, WELCOME_MESSAGE } = require('./prompts');
const { buscarFAQ } = require('../knowledge/policies');
const { buscarPorGeneroOuPalavra, listarDisponiveis, formatarLivro } = require('../knowledge/catalog');
const logger = require('../utils/logger');

const openai = new OpenAI({ apiKey: config.openai.apiKey });

/**
 * Inteligência central do BookBot.
 *
 * Fluxo de processamento:
 *   1. Verifica se é primeiro contato → envia boas-vindas
 *   2. Tenta responder via FAQ local (sem custo de API)
 *   3. Enriquece o contexto com produtos encontrados por busca local
 *   4. Envia histórico + mensagem atual para a OpenAI
 *   5. Verifica se o resultado indica escalada para humano
 *   6. Persiste a resposta no histórico da sessão
 *
 * @param {string} sessionId  - identificador único da conversa
 * @param {string} userMessage - mensagem enviada pelo usuário
 * @returns {Promise<{reply: string, escalate: boolean, source: string}>}
 */
async function processMessage(sessionId, userMessage) {
  // ── 1. Primeiro contato ──────────────────────────────────────────────────
  if (sessionStore.isFirst(sessionId)) {
    sessionStore.addMessage(sessionId, 'user', userMessage);
    sessionStore.addMessage(sessionId, 'assistant', WELCOME_MESSAGE);
    logger.info(`[BookBot] Primeiro contato — sessão ${sessionId}`);
    return { reply: WELCOME_MESSAGE, escalate: false, source: 'welcome' };
  }

  // ── 2. FAQ local (resposta rápida sem custo de API) ───────────────────────
  const faqResposta = buscarFAQ(userMessage);
  if (faqResposta) {
    sessionStore.addMessage(sessionId, 'user', userMessage);
    sessionStore.addMessage(sessionId, 'assistant', faqResposta);
    logger.info(`[BookBot] Respondido via FAQ — sessão ${sessionId}`);
    return { reply: faqResposta, escalate: false, source: 'faq' };
  }

  // ── 3. Enriquecimento de contexto com busca local ─────────────────────────
  let contextExtra = '';
  const livrosEncontrados = buscarPorGeneroOuPalavra(userMessage);
  if (livrosEncontrados.length > 0) {
    contextExtra =
      '\n\n[CONTEXTO ADICIONAL — livros relevantes para esta mensagem:]\n' +
      livrosEncontrados.map(formatarLivro).join('\n---\n');
  }

  // ── 4. Chamada à OpenAI ───────────────────────────────────────────────────
  const systemPrompt = buildSystemPrompt() + contextExtra;
  const messages = [
    { role: 'system', content: systemPrompt },
    ...sessionStore.getMessages(sessionId),
    { role: 'user', content: userMessage },
  ];

  let resposta;
  try {
    const completion = await openai.chat.completions.create({
      model:       config.openai.model,
      max_tokens:  config.openai.maxTokens,
      temperature: config.openai.temperature,
      messages,
    });
    resposta = completion.choices[0]?.message?.content?.trim() || 'Desculpe, não consegui processar sua mensagem.';
    logger.info(`[BookBot] Resposta OpenAI gerada — sessão ${sessionId} | tokens: ${completion.usage?.total_tokens}`);
  } catch (err) {
    logger.error(`[BookBot] Erro na chamada OpenAI: ${err.message}`);
    throw err;
  }

  // ── 5. Detecta pedido de escalada para humano ─────────────────────────────
  const escalate = _deveEscalar(userMessage, resposta);

  // ── 6. Persiste no histórico ──────────────────────────────────────────────
  sessionStore.addMessage(sessionId, 'user', userMessage);
  sessionStore.addMessage(sessionId, 'assistant', resposta);

  return { reply: resposta, escalate, source: 'openai' };
}

/**
 * Detecta se a mensagem ou resposta indica necessidade de atendimento humano.
 * @param {string} userMsg
 * @param {string} botReply
 * @returns {boolean}
 */
function _deveEscalar(userMsg, botReply) {
  const gatilhosUsuario = ['atendente', 'humano', 'pessoa', 'gerente', 'responsável', 'falar com alguem'];
  const gatilhosResposta = ['vou te conectar', 'especialista'];
  const msg = userMsg.toLowerCase();
  const rep = botReply.toLowerCase();
  return (
    gatilhosUsuario.some((g) => msg.includes(g)) ||
    gatilhosResposta.some((g) => rep.includes(g))
  );
}

/**
 * Reseta a conversa de uma sessão (novo atendimento).
 * @param {string} sessionId
 */
function resetSession(sessionId) {
  sessionStore.clearSession(sessionId);
  logger.info(`[BookBot] Sessão resetada: ${sessionId}`);
}

/**
 * Resposta rápida ao catálogo sem passar pela IA.
 * @returns {string}
 */
function listarCatalogo() {
  const livros = listarDisponiveis();
  return (
    '📚 Aqui estão os livros disponíveis na PageStore:\n\n' +
    livros.map(formatarLivro).join('\n\n─────────────────\n\n')
  );
}

module.exports = { processMessage, resetSession, listarCatalogo };
